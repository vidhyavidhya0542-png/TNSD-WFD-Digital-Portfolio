/* script.js */

/* Smooth scrolling for navigation links */

document.querySelectorAll('nav a').forEach(anchor => {

    anchor.addEventListener('click', function(e) {

        e.preventDefault();

        const targetID = this.getAttribute('href').substring(1);

        const targetSection = document.getElementById(targetID);

        targetSection.scrollIntoView({ behavior: 'smooth' });

    });

});

/* Highlight active section in nav while scrolling */

window.addEventListener('scroll', () => {

    const sections = document.querySelectorAll('section');

    const scrollPos = window.scrollY + 100; // Adjust for header height

    sections.forEach(section => {

        const sectionTop = section.offsetTop;

        const sectionHeight = section.offsetHeight;

        const sectionID = section.getAttribute('id');

        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {

            document.querySelectorAll('nav a').forEach(link => {

                link.classList.remove('active');

            });

            const activeLink = document.querySelector(`nav a[href="#${sectionID}"]`);

            if(activeLink) activeLink.classList.add('active');

        }

    });

});


